const CoreDatamapper = require('./core.datamapper');

module.exports = class Armor extends CoreDatamapper {
  tableName = 'armor_data';
};
