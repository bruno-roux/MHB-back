const CoreDatamapper = require('./core.datamapper');

module.exports = class Decoration extends CoreDatamapper {
  tableName = 'decoration';
};
