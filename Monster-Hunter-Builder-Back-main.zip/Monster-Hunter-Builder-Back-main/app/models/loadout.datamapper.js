const CoreDatamapper = require('./core.datamapper');

module.exports = class Loadout extends CoreDatamapper {
  tableName = 'loadout';
};
