const CoreDatamapper = require('./core.datamapper');

module.exports = class Weapon extends CoreDatamapper {
  tableName = 'weapon_data';
};
