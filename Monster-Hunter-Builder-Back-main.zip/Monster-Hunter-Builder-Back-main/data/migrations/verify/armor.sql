-- Verify mhbuilder:armor on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
