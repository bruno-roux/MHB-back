-- Verify mhbuilder:loadout on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
