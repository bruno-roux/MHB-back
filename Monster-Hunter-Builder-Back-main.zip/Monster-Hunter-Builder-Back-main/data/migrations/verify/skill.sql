-- Verify mhbuilder:skill on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
