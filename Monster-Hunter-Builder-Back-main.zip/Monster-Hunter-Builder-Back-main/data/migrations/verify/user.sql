-- Verify mhbuilder:User on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
