-- Verify mhbuilder:weapon on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
